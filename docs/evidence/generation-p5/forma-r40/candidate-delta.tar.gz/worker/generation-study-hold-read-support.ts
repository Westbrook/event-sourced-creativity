import type {WorkerEnv} from './runtime.ts';
import {requireExistingHoldAdministrator,pilotExecutionAllowance} from './pilot-policy.ts';
import {identityFromRequest} from './principal-request-core.ts';
export const QUALIFICATION_ORIGIN='https://forma-creative-studio.reve-ai-0869.chatgpt.site';
export const QUALIFICATION_EXPIRY='2026-10-01T00:00:00Z';
export const QUALIFICATION_OWNER_EMAIL='westbrook.johnson@reve.art';
export const QUALIFICATION_LIMITS={statements:32,rowsPerQuery:1024,queryBytes:100000,resultBytes:1048576,outputBytes:524288,reads:1000000,deadlineMs:20000};
const byteLength=(v:unknown)=>new TextEncoder().encode(JSON.stringify(v)).byteLength;
function fail():never{throw Error('qualification_unavailable');}
const headers={'cache-control':'private, no-store',vary:'Cookie, oai-authenticated-user-id, oai-authenticated-user-email'};
export const qualificationResponse=(v:unknown,status=200)=>Response.json(v,{status,headers});
/** Capability-limited adapter. Only compiled SELECT statements reach D1; no exec,
 * batch or run capability is provided to inherited authentication code. */
export function qualificationReadDb(original:D1Database,limits:typeof QUALIFICATION_LIMITS=QUALIFICATION_LIMITS){
 const metrics={statements:0,reads:0,writes:0,resultBytes:0,databaseBytes:0};const deadline=Date.now()+limits.deadlineMs;
 const check=()=>{if(Date.now()>=deadline)fail();};
 const prepare=(sql:string,values:unknown[]=[]):D1PreparedStatement=>{
  if(!/^\s*SELECT\b/i.test(sql)||sql.includes(';')||new TextEncoder().encode(sql).length>limits.queryBytes||values.length>100)fail();
  const all=async()=>{
   check();if(++metrics.statements>limits.statements)fail();
   const result=await original.prepare(sql).bind(...values).all();check();
   if(!result.success||!Array.isArray(result.results)||result.results.length>limits.rowsPerQuery)fail();
   const m=result.meta;if(!m||typeof m.rows_read!=='number'||!Number.isSafeInteger(m.rows_read)||m.rows_read<0||typeof m.rows_written!=='number'||m.rows_written!==0||typeof m.size_after!=='number'||!Number.isSafeInteger(m.size_after))fail();
   metrics.reads+=m.rows_read;metrics.writes+=m.rows_written;metrics.databaseBytes=Math.max(metrics.databaseBytes,m.size_after);metrics.resultBytes+=byteLength(result.results);
   if(metrics.reads>limits.reads||metrics.resultBytes>limits.resultBytes)fail();
   return result;
  };
  return {bind:(...v:unknown[])=>prepare(sql,v),all,first:async(column?:string)=>{const r=(await all()).results[0] as Record<string,unknown>|undefined;return column?r?.[column]??null:r??null;},run:async()=>fail(),raw:async()=>fail()} as unknown as D1PreparedStatement;
 };
 return {db:{prepare,exec:async()=>fail(),batch:async()=>fail(),dump:async()=>fail()} as unknown as D1Database,metrics,check};
}
/** Inherited principal/consent/policy and personal-only guards. No principal bootstrap.
 * Only DB and non-secret pilot admission configuration are passed to the guard. */
export async function qualificationPrincipal(request:Request,env:WorkerEnv,db:D1Database){
 const u=new URL(request.url),id=identityFromRequest(request);
 if(u.origin!==QUALIFICATION_ORIGIN||u.protocol!=='https:'||u.search||u.hash||request.headers.get('sec-fetch-site')==='cross-site'||(request.headers.has('origin')&&request.headers.get('origin')!==u.origin)||!id||id.source!=='openai-workspace'||id.email!==QUALIFICATION_OWNER_EMAIL)fail();
 const safe={DB:db,FORMA_PILOT_COHORT_ID:env.FORMA_PILOT_COHORT_ID,FORMA_ADMIN_EMAILS:env.FORMA_ADMIN_EMAILS} as WorkerEnv;
 const a=await requireExistingHoldAdministrator(request,safe);
 if(!a.user||a.response||a.user.fictional||a.user.projectExecution||a.user.billingUserId&&a.user.billingUserId!==a.user.userId)fail();
 const allowance=await pilotExecutionAllowance(safe,a.user.userId);if(!allowance.allowed||allowance.pilot!==null)fail();
 return a.user;
}
