import {AsyncLocalStorage} from 'node:async_hooks';
import {readSelectedSourceAuthority,requalifySelectedSourceAuthority} from './reader.mjs';
import M from './manifest.json';
import PAGE from './page.html';
// This entry is exclusively for a separately created private synthetic Site.
const deny=()=>{throw Error('external_effect_forbidden');};
globalThis.fetch=deny as any;
let instance:string;const calls=new AsyncLocalStorage<any>(),envs=new WeakMap<object,any>();
const bytes=(s:string)=>new TextEncoder().encode(s).byteLength;
const hash=async(s:string)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s))),x=>x.toString(16).padStart(2,'0')).join('');
const assert=(x:any,message:string)=>{if(!x)throw Error(message);};
const same=(a:any,b:any)=>JSON.stringify(a)===JSON.stringify(b);
const logical=(r:any)=>{const {configurationBinding,...rest}=r;return rest;};
const limits={reads:60_000_000,writes:1_000_000,inspectionStatements:480,httpInspectionStatements:400,perInspection:80,response:6_000_000,wall:210000,life:3600000};
function meter(results:any[],kind:string,sqls?:any[]){const c=calls.getStore();for(let i=0;i<results.length;i++){const r=results[i];assert(r.success===true,'d1_incomplete');assert(Number.isFinite(r.meta?.rows_read)&&Number.isFinite(r.meta?.rows_written),'metering_unavailable');assert(Number.isFinite(r.meta?.size_after)&&r.meta.size_after<=200_000_000,'database_size_unavailable_or_exceeded');c.databaseBytes=Math.max(c.databaseBytes??0,r.meta.size_after);c.reads+=r.meta.rows_read;c.writes+=r.meta.rows_written;c.statements++;c[kind]=(c[kind]??0)+1;assert(c.reads+c.previousReads<=limits.reads&&c.writes+c.previousWrites<=limits.writes,'resource_envelope_exceeded');if(kind==='inspection'){const op=c.op;op.statements++;assert(op.statements<=limits.perInspection&&c.inspection<=limits.inspectionStatements,'query_envelope_exceeded');assert(r.meta.rows_written===0,'inspection_wrote');op.rowsRead+=r.meta.rows_read;op.resultBytes+=bytes(JSON.stringify(r));op.sql.push({...sqls?.[i],rows:r.results?.length,meta:r.meta});}}assert(c.statements<=limits.httpInspectionStatements,'http_query_envelope_exceeded');}
function checkpoint(){const c=calls.getStore();assert(Date.now()<=c.deadline,'wall_deadline');}
async function batch(db:any,sqls:any[],kind='control'){checkpoint();const rs=await db.batch(sqls.map(([sql,v=[]]:any)=>db.prepare(sql).bind(...v)));meter(rs,kind);return rs;}
async function all(db:any,sql:string,v:any[]=[],kind='control'){return (await batch(db,[[sql,v]],kind))[0].results;}
const guard=[['INSERT INTO n10h_guard(ok) VALUES(changes())'],['DELETE FROM n10h_guard']];
function environment(db:any){let e=envs.get(db);if(e)return e;const refs=new WeakMap();const wrap=(sql:string,v:any[]=[])=>{assert(/^\s*(SELECT|WITH)\b/i.test(sql)&&!/(private_content|artifact_revisions)/i.test(sql),'inspection_effect_forbidden');const w={bind:(...b:any[])=>wrap(sql,b),all:async()=>{checkpoint();const r=await db.prepare(sql).bind(...v).all();meter([r],'inspection',[{sql,bindings:v}]);return r;}};refs.set(w,{sql,bindings:v});return w;};
 e={DB:{prepare:wrap,batch:async(ss:any[])=>{checkpoint();const ds=ss.map(s=>refs.get(s));const rs=await db.batch(ds.map(d=>db.prepare(d.sql).bind(...d.bindings)));meter(rs,'inspection',ds);return rs;}},ASSETS:{fetch:deny}};envs.set(db,e);return e;}
async function body(request:Request,max:number){const reader=request.body?.getReader();assert(reader,'body_required');let n=0,s='';const decoder=new TextDecoder();while(true){const r=await reader!.read();if(r.done)break;n+=r.value.length;if(n>max){await reader!.cancel();throw Error('body_capacity');}s+=decoder.decode(r.value,{stream:true});}return s+decoder.decode();}
async function inspect(db:any,id:string,receipt?:any){const c=calls.getStore(),op={id,instance,statements:0,rowsRead:0,resultBytes:0,sql:[]};const start=Date.now();assert(c.previousReads+c.reads+7_000_000<=limits.reads,'read_headroom');return calls.run({...c,reads:0,writes:0,statements:0,inspection:0,previousReads:c.previousReads+c.reads,previousWrites:c.previousWrites+c.writes,deadline:Math.min(c.deadline,Date.now()+30000),op},async()=>{const child=calls.getStore();let result;try{const q=id==='default-off'?await readSelectedSourceAuthority(environment(db),M.user,'document'):receipt?await requalifySelectedSourceAuthority(environment(db),receipt,{localOnly:true}):await readSelectedSourceAuthority(environment(db),M.user,'document',{localOnly:true});result={ok:true,receipt:q.receipt,snapshot:q.snapshot,readerMetrics:q.metrics};}catch(error){result={ok:false,error:String(error)};}finally{c.reads+=child.reads;c.writes+=child.writes;c.statements+=child.statements;c.inspection+=child.inspection;c.databaseBytes=Math.max(c.databaseBytes??0,child.databaseBytes??0);}return {...op,...result,wallMs:Date.now()-start};});}
export default {async fetch(request:Request,bindings:any){
 instance??=crypto.randomUUID();const c={reads:0,writes:0,previousReads:0,previousWrites:0,statements:0,inspection:0,deadline:Date.now()+30000};
 return calls.run(c,async()=>{let db=bindings.DB;try{
  assert(db&&Object.keys(bindings).every(k=>['DB','ASSETS'].includes(k)),'bindings_not_isolated');
  const url=new URL(request.url),uid=request.headers.get('oai-authenticated-user-id'),email=request.headers.get('oai-authenticated-user-email');
  assert(uid&&uid.length<=256&&email&&await hash(email.trim().toLowerCase())===M.ownerEmailSha256,'owner_required');
  if(request.method==='GET'&&url.pathname==='/')return new Response(PAGE,{headers:{'content-type':'text/html;charset=utf-8','cache-control':'no-store'}});
  if(request.method==='GET'&&/^\/fixture\/(?:manifest|\d+)\.json$/.test(url.pathname)){assert(bindings.ASSETS,'assets_unavailable');return bindings.ASSETS.fetch(request);}
  assert(request.method==='POST'&&url.pathname==='/case'&&request.headers.get('origin')===url.origin&&request.headers.get('content-type')==='application/json','same_origin_json_required');
  const input=JSON.parse(await body(request,260000));assert(input&&typeof input==='object'&&!Array.isArray(input),'case_required');
  const action=input.case;if(action==='proof')c.deadline=Date.now()+limits.wall;assert(['start','import','finish','proof','cleanup'].includes(action),'case_denied');assert(Object.keys(input).every(k=>(action==='import'?['case','id','chunk']:['case']).includes(k)),'unexpected_control');
  if(action==='start'){
   const empty=Object.keys(M.tables).map(t=>`NOT EXISTS(SELECT 1 FROM "${t}")`).join(' AND ');
   await batch(db,[[`INSERT INTO n10h_run(id,owner,phase,next,started,cleanup,reads,writes) SELECT 1,?,'importing',0,?,0,0,0 WHERE ${empty}`,[uid,Date.now()]],...guard]);
  }else{
   const state=(await all(db,'SELECT * FROM n10h_run WHERE id=1'))[0];assert(state&&state.owner===uid,'owner_or_run_invalid');c.previousReads=state.reads;c.previousWrites=state.writes;assert(state.phase!=='disabled','run_disabled');assert(action==='cleanup'||Date.now()-state.started<limits.life,'run_expired');
   if(action==='import'){
    const spec=M.chunks[input.id];assert(spec&&spec.id===input.id&&state.phase==='importing'&&state.next===input.id,'chunk_order_or_duplicate');assert(typeof input.chunk==='string'&&bytes(input.chunk)===spec.bytes&&await hash(input.chunk)===spec.sha256,'chunk_hash');const rows=JSON.parse(input.chunk);assert(Array.isArray(rows)&&rows.length===spec.rows,'chunk_rows');
    await batch(db,[[`UPDATE n10h_run SET next=next+1 WHERE id=1 AND phase='importing' AND next=?`,[input.id]],...guard,[(M.tables as any)[spec.table].insert,[input.chunk]]],'setup');
   }else if(action==='finish'){
    assert(state.phase==='importing'&&state.next===M.chunks.length,'import_incomplete');for(const [table,count] of Object.entries(M.counts)){const r=await all(db,`SELECT count(*) AS n FROM "${table}"`,[],'setup');assert(r[0].n===count,'fixture_count');}
    await batch(db,[[`UPDATE n10h_run SET phase='ready' WHERE id=1 AND phase='importing' AND next=?`,[M.chunks.length]],...guard]);
   }else if(action==='proof'){
    assert(state.phase==='ready','proof_not_ready_or_consumed');await batch(db,[[`UPDATE n10h_run SET phase='running' WHERE id=1 AND phase='ready'`],...guard]);
    const results:any[]=[];let verdict='functional-pass';
    try{
     const cold:any=await inspect(db,'cold');assert(cold.ok&&same(logical(cold.receipt),logical(M.expectedReceipt))&&same(cold.snapshot,M.expectedSnapshot),'cold_mismatch');results.push(cold);
     for(const id of ['warm','requalification']){const r:any=await inspect(db,id,id==='requalification'?cold.receipt:undefined);results.push(r);assert(r.ok&&same(r.receipt,cold.receipt)&&same(r.snapshot,M.expectedSnapshot),'same_instance_mismatch');}
     // Shared root counters are reconciled from each operation below; no mutable
     // receipt/env identity is changed between overlapping read-only operations.
     const before={reads:c.reads,writes:c.writes,statements:c.statements,inspection:c.inspection};
     const pair:any[]=await Promise.all([inspect(db,'overlap-a'),inspect(db,'overlap-b')]);
     c.reads=before.reads+pair.reduce((n,r)=>n+r.rowsRead,0);c.writes=before.writes;c.statements=before.statements+pair.reduce((n,r)=>n+r.statements,0);c.inspection=before.inspection+pair.reduce((n,r)=>n+r.statements,0);
     results.push(...pair);for(const r of pair)assert(r.ok&&same(r.receipt,cold.receipt)&&same(r.snapshot,M.expectedSnapshot),'overlap_mismatch');
     const original=(await all(db,'SELECT private_json FROM event_private_payloads WHERE private_event_id=?',[M.mutationId],'mutation'))[0]?.private_json;assert(typeof original==='string'&&original.split('harbor').length===2,'mutation_precondition');const changed=original.replace('harbor','forest');assert(bytes(changed)===bytes(original),'mutation_length');
     await batch(db,[['UPDATE event_private_payloads SET private_json=? WHERE private_event_id=? AND private_json=?',[changed,M.mutationId,original]],...guard],'mutation');
     const denied:any=await inspect(db,'mutation-denial',cold.receipt);results.push(denied);assert(!denied.ok&&denied.error==='Error: selected_authority_changed','mutation_not_denied');
     const gate:any=await inspect(db,'default-off');results.push(gate);assert(!gate.ok&&gate.error==='Error: selected_gate_off'&&gate.statements===0,'gate_not_off');
    }catch(e){verdict='functional-refusal';results.push({error:String(e),instance});}
    const report={version:M.version,instance,verdict,results,observed:{...c,deadline:undefined},hostedResourceQualified:false,realWorkspaceQualified:false};const serialized=JSON.stringify(report);assert(bytes(serialized)<limits.response,'response_capacity');
    await batch(db,[[`UPDATE n10h_run SET phase='finished',report=? WHERE id=1 AND phase='running'`,[JSON.stringify({instance,verdict,evidenceSha256:await hash(serialized)})]],...guard]);
    await batch(db,[['UPDATE n10h_run SET reads=reads+?,writes=writes+? WHERE id=1',[c.reads+8,c.writes+8]]]);
    return Response.json({...report,lifecycleMetrics:{...c,deadline:undefined}},{headers:{'cache-control':'no-store'}});
   }else if(action==='cleanup'){
    assert(state.phase!=='running'||Date.now()-state.started>=limits.life,'proof_running');
    const plan=M.chunks[state.cleanup];if(plan){await batch(db,[[`UPDATE n10h_run SET phase='cleaning',cleanup=cleanup+1 WHERE id=1 AND cleanup=? AND phase IN('importing','ready','finished','cleaning','running')`,[state.cleanup]],...guard,[`DELETE FROM "${plan.table}" WHERE rowid IN(SELECT rowid FROM "${plan.table}" LIMIT ?)`,[plan.rows]]],'cleanup');}
    else{for(const t of Object.keys(M.tables)){const rows=await all(db,`SELECT count(*) AS n FROM "${t}"`,[],'cleanup');assert(rows[0].n===0,'cleanup_incomplete');}await batch(db,[[`UPDATE n10h_run SET phase='disabled',report=NULL WHERE id=1 AND cleanup=?`,[M.chunks.length]],...guard],'cleanup');}
   }
  }
  await batch(db,[['UPDATE n10h_run SET reads=reads+?,writes=writes+? WHERE id=1',[c.reads+8,c.writes+8]]]);
  return Response.json({ok:true,case:action,instance,metrics:c},{headers:{'cache-control':'no-store'}});
 }catch(e){return Response.json({ok:false,error:String(e),instance,metrics:c},{status:409,headers:{'cache-control':'no-store'}});}});
}};
